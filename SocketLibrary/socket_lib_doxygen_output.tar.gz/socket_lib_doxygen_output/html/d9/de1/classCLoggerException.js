var classCLoggerException =
[
    [ "CLoggerException", "d9/de1/classCLoggerException.html#ae14f1a264ddc7181ff19e36e3f9cd69d", null ],
    [ "~CLoggerException", "d9/de1/classCLoggerException.html#a2604baa2d3fc6f13c83d5c606fd99941", null ],
    [ "what", "d9/de1/classCLoggerException.html#a0f91ad11b6665d3348a8eb66d5bcfe4e", null ],
    [ "m_message", "d9/de1/classCLoggerException.html#a4bbe88a45b230e4f6ca3246999c8348a", null ]
];