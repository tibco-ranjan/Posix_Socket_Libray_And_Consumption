var client_8cpp =
[
    [ "MAXDATASIZE", "d9/d95/client_8cpp.html#a16c16f9369be4a374a3e621f6d13bb16", null ],
    [ "func", "d9/d95/client_8cpp.html#ac17020a38607ab29ce18939d5194a32a", null ],
    [ "main", "d9/d95/client_8cpp.html#a0ddf1224851353fc92bfbff6f499fa97", null ]
];