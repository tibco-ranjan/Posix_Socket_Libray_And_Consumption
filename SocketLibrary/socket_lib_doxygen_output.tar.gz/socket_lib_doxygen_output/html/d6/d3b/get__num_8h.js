var get__num_8h =
[
    [ "myAtoi", "d6/d3b/get__num_8h.html#aafea1112c7333dcfa49a8d051c2bde9a", null ],
    [ "myAtol", "d6/d3b/get__num_8h.html#afc17dbeb125e1388078e1a9221624f15", null ]
];