var dir_a3ffbd8d063419c1ced621fc2351bb18 =
[
    [ "client.cpp", "d9/d95/client_8cpp.html", "d9/d95/client_8cpp" ]
];