var dir_eb3b43e9971bb9ff840f38b0ab8b9065 =
[
    [ "source", "dir_a3ffbd8d063419c1ced621fc2351bb18.html", "dir_a3ffbd8d063419c1ced621fc2351bb18" ],
    [ "Makefile", "d8/dfa/ClientServer_2client_2Makefile.html", "d8/dfa/ClientServer_2client_2Makefile" ]
];