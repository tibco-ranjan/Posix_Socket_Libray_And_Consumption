var dir_616d43e3a77be9d454eca07030494db4 =
[
    [ "source", "dir_70881a9ae68e80decfeb0179e96f4a71.html", "dir_70881a9ae68e80decfeb0179e96f4a71" ],
    [ "Makefile", "d0/d08/ClientServer_2server_2Makefile.html", "d0/d08/ClientServer_2server_2Makefile" ]
];