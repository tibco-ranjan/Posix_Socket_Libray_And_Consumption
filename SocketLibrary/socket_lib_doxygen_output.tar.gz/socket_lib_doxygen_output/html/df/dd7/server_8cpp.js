var server_8cpp =
[
    [ "FALSE", "df/dd7/server_8cpp.html#aa93f0eb578d23995850d61f7d61c55c1", null ],
    [ "TRUE", "df/dd7/server_8cpp.html#aa8cecfc5c5c054d2875c03e77b7be15d", null ],
    [ "main", "df/dd7/server_8cpp.html#a0ddf1224851353fc92bfbff6f499fa97", null ]
];