var namespaces =
[
    [ "DateTime", "d0/d9c/namespaceDateTime.html", null ]
];