var ClientServer_2Makefile =
[
    [ "do", "dd/d60/ClientServer_2Makefile.html#a54d2d882a8cc61f85bf978b5e4317ab1", null ],
    [ "SUBDIRS", "dd/d60/ClientServer_2Makefile.html#a290c239123caef8485b75428c4acc522", null ]
];