var tlpi__hdr_8h =
[
    [ "max", "d4/d75/tlpi__hdr_8h.html#aae5d226fe30fc72743bf5b8b3d691fe7", null ],
    [ "min", "d4/d75/tlpi__hdr_8h.html#a69db94a857e4ed0645c48085b2e3bd0a", null ],
    [ "TLPI_HDR_H", "d4/d75/tlpi__hdr_8h.html#a2a9e49dec41ddabf74cd01742996228f", null ],
    [ "BOOLEAN", "d4/d75/tlpi__hdr_8h.html#aec7e62084419d7857ae740a4c68241cf", [
      [ "FALSE", "d4/d75/tlpi__hdr_8h.html#aec7e62084419d7857ae740a4c68241cfaa1e095cc966dbecf6a0d8aad75348d1a", null ],
      [ "TRUE", "d4/d75/tlpi__hdr_8h.html#aec7e62084419d7857ae740a4c68241cfaa82764c3079aea4e60c80e45befbb839", null ]
    ] ]
];