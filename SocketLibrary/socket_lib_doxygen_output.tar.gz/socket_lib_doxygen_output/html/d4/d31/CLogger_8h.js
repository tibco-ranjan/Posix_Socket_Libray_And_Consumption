var CLogger_8h =
[
    [ "CLogger", "d4/dbe/classCLogger.html", "d4/dbe/classCLogger" ],
    [ "LOGGER", "d4/d31/CLogger_8h.html#aa385268d3ec7b4d3ecceb7c787171bf0", null ]
];