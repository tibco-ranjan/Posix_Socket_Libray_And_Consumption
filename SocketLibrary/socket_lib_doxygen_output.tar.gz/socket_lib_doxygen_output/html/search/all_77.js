var searchData=
[
  ['what',['what',['../d9/de1/classCLoggerException.html#a0f91ad11b6665d3348a8eb66d5bcfe4e',1,'CLoggerException']]]
];
