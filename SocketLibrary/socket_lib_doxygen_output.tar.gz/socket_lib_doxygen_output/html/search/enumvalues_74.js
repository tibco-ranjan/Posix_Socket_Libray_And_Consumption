var searchData=
[
  ['true',['TRUE',['../d4/d75/tlpi__hdr_8h.html#aec7e62084419d7857ae740a4c68241cfaa82764c3079aea4e60c80e45befbb839',1,'tlpi_hdr.h']]]
];
