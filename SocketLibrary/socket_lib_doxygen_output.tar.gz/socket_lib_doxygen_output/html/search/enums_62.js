var searchData=
[
  ['boolean',['BOOLEAN',['../d4/d75/tlpi__hdr_8h.html#aec7e62084419d7857ae740a4c68241cf',1,'tlpi_hdr.h']]]
];
