var searchData=
[
  ['noreturn',['NORETURN',['../df/d33/error__functions_8h.html#aa1728270d73c5d1598de1fd691762eb1',1,'error_functions.h']]],
  ['not_5flisten',['NOT_LISTEN',['../d9/dc9/inet__socket_8h.html#aaa31440706ba11d449ccebfb07611495',1,'inet_socket.h']]]
];
