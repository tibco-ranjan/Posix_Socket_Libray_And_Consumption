var searchData=
[
  ['do',['do',['../dd/d60/ClientServer_2Makefile.html#a54d2d882a8cc61f85bf978b5e4317ab1',1,'do(MAKE)-C $$dir-f Makefile $@:&#160;Makefile'],['../d9/d65/Makefile.html#a54d2d882a8cc61f85bf978b5e4317ab1',1,'do(MAKE)-C $$dir-f Makefile $@:&#160;Makefile']]]
];
