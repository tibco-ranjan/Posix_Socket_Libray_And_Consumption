var searchData=
[
  ['false',['FALSE',['../d4/d75/tlpi__hdr_8h.html#aec7e62084419d7857ae740a4c68241cfaa1e095cc966dbecf6a0d8aad75348d1a',1,'tlpi_hdr.h']]]
];
