var searchData=
[
  ['backlog',['BACKLOG',['../d9/dc9/inet__socket_8h.html#aeefbbafa97642defe3ee6c3080b7d66f',1,'inet_socket.h']]],
  ['buff_5fsize',['BUFF_SIZE',['../dd/d35/error__functions_8c.html#a6c7cd32e1bac137f05e4a752b4ad10af',1,'error_functions.c']]]
];
