var searchData=
[
  ['readline',['readLine',['../d3/d61/readLine_8h.html#ae5fe12dcd80500477715cce8c11a29b5',1,'readLine(int fd, char *buff, size_t n):&#160;readLine.cpp'],['../d3/d5c/readLine_8cpp.html#ae5fe12dcd80500477715cce8c11a29b5',1,'readLine(int fd, char *buff, size_t n):&#160;readLine.cpp']]]
];
