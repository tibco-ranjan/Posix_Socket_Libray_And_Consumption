var searchData=
[
  ['subdirs',['SUBDIRS',['../dd/d60/ClientServer_2Makefile.html#a290c239123caef8485b75428c4acc522',1,'SUBDIRS():&#160;Makefile'],['../d9/d65/Makefile.html#a290c239123caef8485b75428c4acc522',1,'SUBDIRS():&#160;Makefile']]]
];
