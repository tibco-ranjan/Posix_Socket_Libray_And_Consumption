var searchData=
[
  ['the',['the',['../d8/dfa/ClientServer_2client_2Makefile.html#a09c6b60bb7451f9136e25140ffdff6bd',1,'the():&#160;Makefile'],['../d0/d08/ClientServer_2server_2Makefile.html#a09c6b60bb7451f9136e25140ffdff6bd',1,'the():&#160;Makefile']]],
  ['tlpi_5fhdr_5fh',['TLPI_HDR_H',['../d4/d75/tlpi__hdr_8h.html#a2a9e49dec41ddabf74cd01742996228f',1,'tlpi_hdr.h']]],
  ['true',['TRUE',['../df/dd7/server_8cpp.html#aa8cecfc5c5c054d2875c03e77b7be15d',1,'TRUE():&#160;server.cpp'],['../da/d4e/inet__accept_8h.html#aa8cecfc5c5c054d2875c03e77b7be15d',1,'TRUE():&#160;inet_accept.h']]]
];
