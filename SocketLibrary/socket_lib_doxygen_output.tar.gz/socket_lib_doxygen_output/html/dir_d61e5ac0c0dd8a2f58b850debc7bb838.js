var dir_d61e5ac0c0dd8a2f58b850debc7bb838 =
[
    [ "include", "dir_aeda4f6862a328d4902b37053f9be1df.html", "dir_aeda4f6862a328d4902b37053f9be1df" ],
    [ "source", "dir_c5f260f06f8ea0c7169cb637da2cda86.html", "dir_c5f260f06f8ea0c7169cb637da2cda86" ],
    [ "Makefile", "dc/d70/tcpSocket_2Makefile.html", null ],
    [ "README", "d8/d4a/tcpSocket_2README.html", "d8/d4a/tcpSocket_2README" ]
];