var dir_5c70d44407ddaa33db772a7cc5a16b15 =
[
    [ "client", "dir_eb3b43e9971bb9ff840f38b0ab8b9065.html", "dir_eb3b43e9971bb9ff840f38b0ab8b9065" ],
    [ "server", "dir_616d43e3a77be9d454eca07030494db4.html", "dir_616d43e3a77be9d454eca07030494db4" ],
    [ "Makefile", "dd/d60/ClientServer_2Makefile.html", "dd/d60/ClientServer_2Makefile" ]
];