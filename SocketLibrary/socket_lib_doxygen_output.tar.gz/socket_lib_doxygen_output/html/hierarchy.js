var hierarchy =
[
    [ "CLogger", "d4/dbe/classCLogger.html", null ],
    [ "CMutex", "df/d7d/classCMutex.html", null ],
    [ "exception", null, [
      [ "CLoggerException", "d9/de1/classCLoggerException.html", null ]
    ] ]
];