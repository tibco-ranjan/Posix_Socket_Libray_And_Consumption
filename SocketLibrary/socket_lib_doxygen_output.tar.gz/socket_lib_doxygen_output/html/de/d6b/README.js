var README =
[
    [ "Prasad", "de/d6b/README.html#acbcec0b507f57bc6fea73bd91bc0323f", null ],
    [ "CENTOS", "de/d6b/README.html#abec6047e55a548b2b675ef60ec1a1ff0", null ],
    [ "Host", "de/d6b/README.html#a38037a5a8331147623d2579e11a55ddc", null ],
    [ "RHEL", "de/d6b/README.html#acced105257a718491134c7cae002d48a", null ]
];