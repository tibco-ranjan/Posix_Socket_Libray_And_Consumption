var aupe_8h =
[
    [ "mode", "de/d06/aupe_8h.html#af613cadd5cf49515a2b8790d3bfd56af", null ],
    [ "oflag", "de/d06/aupe_8h.html#ae5e23dea252ef3137f9d0e5e63b0d770", null ]
];