var source_2inet__handle__multiplex__io_8cpp =
[
    [ "MAXDATASIZE", "d1/d52/source_2inet__handle__multiplex__io_8cpp.html#a16c16f9369be4a374a3e621f6d13bb16", null ],
    [ "inet_handle_multiplex_io", "d1/d52/source_2inet__handle__multiplex__io_8cpp.html#a5b7d00b9255711bb21248a110db46c9a", null ]
];